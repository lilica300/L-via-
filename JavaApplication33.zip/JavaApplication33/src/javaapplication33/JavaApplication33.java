/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication33;

import javax.swing.JOptionPane;

/**
 *
 * @author livia.ramachado
 */
public class JavaApplication33 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
        //JOptionPane.showMessageDialog(null,"eu odeio ti"); 
       //JOptionPane.showMessageDialog(null,"cansei ja");  
       JOptionPane.showInputDialog(null,"eu odeio ti");
          
        
        
    }
    
}
