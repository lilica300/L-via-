/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication100;

import javax.swing.JOptionPane;

/**
 *
 * @author livia.ramachado
 */
public class JavaApplication100 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
        String cpf = JOptionPane.showInputDialog(null, "Digite seu CPF");
        String nome = JOptionPane.showInputDialog(null, "Digite seu nome");
        JOptionPane.showMessageDialog(null, "Seu cpf é " + cpf + " e seu nome é " + nome);
    }
    
}
