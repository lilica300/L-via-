/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication200;

import javax.swing.JOptionPane;

/**
 *
 * @author livia.ramachado
 */
public class JavaApplication200 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
        for (int i = 0; i < 8; i++) {
            JOptionPane.showMessageDialog(null, "teste " + i);
        }
    }
    
}
