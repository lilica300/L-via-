/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication33;

import javax.swing.JOptionPane;

/**
 *
 * @author livia.ramachado
 */
public class JavaApplication33 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
        //JOptionPane.showMessageDialog(null,"eu "); 
       //JOptionPane.showMessageDialog(null,"cansei ja");  
      // JOptionPane.showInputDialog(null,"qual seu nome?"); 
        int opcao = JOptionPane.showConfirmDialog(null," deseja fazer um pix"); 
        
        if (opcao == 0) {
         JOptionPane.showMessageDialog(null,"qual o valor? ");    
        } 
        else if(opcao == 1 ){ 
          JOptionPane.showMessageDialog(null," qual o motivo? ");   
        } 
         else if(opcao == 2){ 
          JOptionPane.showMessageDialog(null," qual o motivo? ");   
        }
        
        else{ 
      
          
         }
        
    }
    
}
